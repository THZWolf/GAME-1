# NEON FRONTIER — GAME-1

Protótipo original de jogo de navegador que combina três pilares de design:
- exploração urbana em mundo aberto;
- construção e experimentação em sandbox;
- atmosfera futurista neon/cyberpunk.

As referências são de alto nível: este projeto não copia código-fonte, personagens, mapas, músicas, marcas ou ativos proprietários de GTA V, Minecraft ou Cyberpunk 2077.

## Executar
Abra `index.html` em um navegador moderno. Não precisa instalar dependências.

## Controles
- WASD / setas: mover
- E: interagir, coletar ou entrar/sair do veículo
- B: colocar bloco
- R: recuperar bloco próximo
- Q: observar e registrar uma observação
- 1–4: testar símbolos no terminal de padrões

## ARC-AGI-3
O protótipo usa ações sequenciais, feedback visível, um desafio de inferência de padrão e um registro de ações, inspirado no estilo de raciocínio interativo do ARC-AGI-3. **Ainda não é um ambiente oficial compatível com o toolkit**: não implementa o contrato oficial do SDK, scorecards ou pontuação de competição.

Veja `docs/ARC-AGI-3.md` para a distinção e próximos passos.

Referências oficiais:
- https://docs.arcprize.org/toolkit/overview
- https://github.com/arcprize/ARC-AGI
- https://arcprize.org/arc-agi/3
