# ARC-AGI-3 — mapeamento de design do NEON FRONTIER

Este documento distingue inspiração conceitual de compatibilidade técnica.

| Princípio | Protótipo |
|---|---|
| Interação sequencial | Cada movimento/interação altera o estado e incrementa o contador de ações. |
| Observação e feedback | Q registra uma observação resumida; as ações produzem mensagens de feedback. |
| Inferir objetivos | Fragmentos e terminal central são pistas ambientais. |
| Experimentar regras | O terminal tem uma sequência de quatro símbolos e responde a cada tentativa. |
| Planejamento em várias etapas | Coletar cinco fragmentos, navegar, resolver o terminal e gerir blocos. |
| Inspecionar comportamento | Registro de ações no HUD. |

## Limite de compatibilidade

O toolkit oficial `arc-agi` é um SDK Python para carregar ambientes ARC-AGI-3 e conectar agentes. Este jogo HTML/Canvas é independente; não usa o SDK para observações, ações, scorecards ou pontuação oficial. O rótulo ARC no protótipo descreve inspiração de design, não certificação.

## Próxima etapa técnica
Criar um adaptador de ambiente em Python, separado do renderizador, e validar o formato de observação/ação e os testes do SDK oficial antes de afirmar compatibilidade.

## Referências
- https://docs.arcprize.org/toolkit/overview
- https://github.com/arcprize/ARC-AGI
- https://arcprize.org/arc-agi/3
